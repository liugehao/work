<?php
echo $_POST['data'] . rand(1,100);
